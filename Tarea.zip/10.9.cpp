//Explicacion:

/*

//a) Como funciona:

(HugeInteger.cpp)
-Se declara el contructor por defecto que realizando un "for" encaja
los argumentos en una matriz

El constructor de conversion convierte los caracteres a strings

El operador de adición inicialisa un "carry" y crea resultados temporales
a partir de los enteros generados anteriormente para verificar cunado el
"carry" llevara "1"

El operador de adicion tambien retorna un "op2" convertido a un
"HugeInteger"   

El operador de sobrecarga omite los ceros a la izquierda



//b) ¿Que restricciones tiene la clase?:

-Tiene como maximo 40 digitos para un "HugeInteger"



*/