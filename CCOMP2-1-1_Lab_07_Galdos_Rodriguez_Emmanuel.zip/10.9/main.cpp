 #include <iostream>
#include "HugeInteger.h"
using namespace std;

int main() {
HugeInteger n1{7654321};
HugeInteger n2{7891234};
HugeInteger n3{"99999999999999999999999999999"};
HugeInteger n4{"1"};
HugeInteger n5;
HugeInteger n6{556},n7{557};
cout<< n7.cdigits<<endl;
cout << n7*n6<< endl;
HugeInteger n8=n7*n6;
cout<< n8<<endl;
cout<<n8.cdigits<<endl;
cout<<n7/n6<<endl;
if (n6<n7){
    cout<< "menor"<<endl;
}
else if(n6>n7){
    cout<< "mayor"<<endl;
}
else { cout <<"igual"<<endl;}

cout << "n1 is " << n1 << "\nn2 is " << n2
<< "\nn3 is " << n3 << "\nn4 is " << n4
<< "\nn5 is " << n5 << "\n\n";

n5 = n1 + n2;
cout << n1 << " + " << n2 << " = " << n5 << "\n\n";

cout << n3 << " + " << n4 << "\n= " << (n3 + n4) << "\n\n";

n5 = n1 + 9;
cout << n1 << " + " << 9 << " = " << n5 << "\n\n";

n5 = n2 + "10000";
cout << n2 << " + " << "10000" << " = " << n5 << endl;
}
