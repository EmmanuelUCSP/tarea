#ifndef HugeInteger_H
#define HugeInteger_H

#include <array>
#include <iostream>
#include <string>

class HugeInteger {
friend std::ostream& operator<<(std::ostream&, const HugeInteger&);
public:
static const int digits{40}; // maximum digits in a HugeInteger
int cdigits=1;

HugeInteger(long = 0); // conversion/default constructor
HugeInteger(const std::string&); // conversion constructor


HugeInteger operator+(const HugeInteger&) const;

HugeInteger operator+(int) const;

HugeInteger operator+(const std::string&) const;

HugeInteger operator*(const HugeInteger&) const;

HugeInteger operator*(int) const;

HugeInteger operator*(const std::string&) const;

HugeInteger operator/(const HugeInteger&) const;

HugeInteger operator/(int) const;

HugeInteger operator/(const std::string&) const;

HugeInteger operator++() const;

bool operator==(const HugeInteger) const;

bool operator<=(const HugeInteger) const;

bool operator>=(const HugeInteger) const;

bool operator<(const HugeInteger) const;

bool operator>(const HugeInteger) const;

HugeInteger operator/(const HugeInteger);
private:
std::array<short, digits> integer{}; // default init to 0s

};

#endif
