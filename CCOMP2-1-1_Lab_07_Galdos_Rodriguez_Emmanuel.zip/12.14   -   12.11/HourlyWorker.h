#ifndef HOURLYWORKER_H
#define HOURLYWORKER_H
#include <string>
#include "Employee.h"

class HourlyWorker:public Employee
{
    public:
        HourlyWorker(const std::string&,const std::string&, const std::string&,
                    const Date&,int = 0, double= 0.0 );
        virtual ~HourlyWorker()=default;

        void setHours(int);
        int getHours() const;

        void setWage(double);
        double getWage() const;

        virtual double earnings() const override;
        virtual std::string toString() const override;
    private:
        int hWorked;
        double wage;
        double scale = 1.0;
};
#endif // HOURLYWORKER_H
