#ifndef BASEPLUSCOMISSIONEMPLOYEE_H
#define BASEPLUSCOMISSIONEMPLOYEE_H


#include <string> // C++ standard string class
 #include "ComissionEmployee.h" // CommissionEmployee class definition

 class BasePlusCommissionEmployee:public CommissionEmployee {
 public:
 BasePlusCommissionEmployee(const std::string&, const std::string&,
 const std::string&,const Date&, double = 0.0, double = 0.0, double = 0.0);
 virtual ~BasePlusCommissionEmployee() = default; // virtual destructor

 void setBaseSalary(double); // set base salary
 double getBaseSalary() const; // return base salary
virtual double earnings() const override; // calculate earnings
virtual std::string toString() const override;
private:
 double baseSalary; // base salary per week
 };
#endif // BASEPLUSCOMISSIONEMPLOYEE_H
