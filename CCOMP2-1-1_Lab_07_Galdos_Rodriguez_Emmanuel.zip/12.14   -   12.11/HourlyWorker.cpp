#include <iomanip>
 #include <stdexcept>
 #include <sstream>
 #include "HourlyWorker.h" // CommissionEmployee class definition
 using namespace std;

 // constructor
 HourlyWorker::HourlyWorker(const string &first,
 const string &last, const string &ssn,const Date& bd, int hours, double wage)
 : Employee(first, last, ssn, bd)
 {
 setHours(hours);
 setWage(wage);
 if (hours>40) scale = 1.5;
 }

 // set gross sales amount
 void HourlyWorker::setWage(double wage) {
 if (wage < 0.0) {
 throw invalid_argument("Wage per piece must be >= 0.0");
 }

 this->wage = wage;
 }

 // return gross sales amount
 double HourlyWorker::getWage() const {return wage;}

 // set commission rate
 void HourlyWorker::setHours(int hours) {
 if (hWorked <0) {
 throw invalid_argument("Hours worked must be > 0");
 }

 hWorked= hours;
 }

 // return commission rate
 int HourlyWorker::getHours() const {
 return hWorked;
 }

 // calculate earnings; override pure virtual function earnings in Employee
 double HourlyWorker::earnings() const {
if (scale>1.0){
    return 40 * getWage()+(getHours()-40)*getWage()*scale;}
    return getHours() *getWage();
 }

 // return a string representation of CommissionEmployee's information
 string HourlyWorker::toString() const {
 ostringstream output;
 output << fixed << setprecision(2);
 output << "Hour Worker employee: " <<Employee::toString()
 << "\nHours worked: " << getHours()
 << "; wage per hour: " << getWage();
 return output.str();
 }
