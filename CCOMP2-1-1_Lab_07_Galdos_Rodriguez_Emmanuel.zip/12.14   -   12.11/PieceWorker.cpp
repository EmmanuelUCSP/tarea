#include <iomanip>
 #include <stdexcept>
 #include <sstream>
 #include "PieceWorker.h" // CommissionEmployee class definition
 using namespace std;

 // constructor
 PieceWorker::PieceWorker(const string &first,
 const string &last, const string &ssn,const Date& bd, int pieces, double wage)
 : Employee(first, last, ssn, bd)
 {
 setPieces(pieces);
 setWage(wage);
 }

 // set gross sales amount
 void PieceWorker::setWage(double wage) {
 if (wage < 0.0) {
 throw invalid_argument("Wage per piece must be >= 0.0");
 }

 this->wage = wage;
 }

 // return gross sales amount
 double PieceWorker::getWage() const {return wage;}

 // set commission rate
 void PieceWorker::setPieces(int pieces) {
 if (pieces <0) {
 throw invalid_argument("Pieces sold must be > 0");
 }

 this->pieces= pieces;
 }

 // return commission rate
 int PieceWorker::getPieces() const {
 return pieces;
 }

 // calculate earnings; override pure virtual function earnings in Employee
 double PieceWorker::earnings() const {
 return getPieces() * getWage();
 }

 // return a string representation of CommissionEmployee's information
 string PieceWorker::toString() const {
 ostringstream output;
 output << fixed << setprecision(2);
 output << "Piece Worker employee: " <<Employee::toString()
 << "\nPieces sold: " << getPieces()
 << "; wage per piece sold: " << getWage();
 return output.str();
 }
